/**

*/
package com.consentframework.consentmanagement.sdk;

import javax.annotation.Generated;
import com.consentframework.consentmanagement.sdk.model.*;
import com.amazonaws.*;
import com.amazonaws.opensdk.*;
import com.amazonaws.opensdk.model.*;

/**
 * Abstract implementation of {@code ConsentManagementApi}.
 */
@Generated("com.amazonaws:aws-java-sdk-code-generator")
public class AbstractConsentManagementApi implements ConsentManagementApi {

    protected AbstractConsentManagementApi() {
    }

    @Override
    public CreateServiceUserConsentResult createServiceUserConsent(CreateServiceUserConsentRequest request) {
        throw new java.lang.UnsupportedOperationException();
    }

    @Override
    public GetServiceUserConsentResult getServiceUserConsent(GetServiceUserConsentRequest request) {
        throw new java.lang.UnsupportedOperationException();
    }

    @Override
    public ListServiceUserConsentResult listServiceUserConsent(ListServiceUserConsentRequest request) {
        throw new java.lang.UnsupportedOperationException();
    }

    @Override
    public UpdateServiceUserConsentResult updateServiceUserConsent(UpdateServiceUserConsentRequest request) {
        throw new java.lang.UnsupportedOperationException();
    }

    @Override
    public void shutdown() {
        throw new java.lang.UnsupportedOperationException();
    }

}
